# Virtual Event Management System

To assist  organizations to reach global audiences by hosting online conferences, exhibitions and competitions.

# Features:

### Virtual Event Lobby

#### Virtual Event Registration
- Allow attendees to easily register, buy tickets and select their agenda.
- Upload payment slip after registration
- Participant profile
- Upload abstract, poster, book chapters (submission page)

#### Speakers
- Info
- Upload contents
- Live streaming videos (in platform is possible)

#### Interactive Virtual Sessions (Virtual room) - participants and visitors
- Concurrent sessions, rooms and speakers
- Uploadable pre-recorded video, poster, abstract
- Downloadable contents within sessions
- Live chat feed (chat box) and private Q&A (*important”)

#### Backend 
- mainly to manage the participants registration and exhibition and competition booths

#### Offer Virtual Sponsorships (Virtual Booth)
- Custom exhibitor profile with downloadable content
- Enable demos or  pre-recorded video promo
- Google map (contact us)

#### Prize giving & Closing ceremony
