
export enum Role {
    // User = 'user',
    Admin = 'admin',
    Participant = 'participant',
    Visitor = 'visitor',
    Sponsor = 'sponsor',
    Judge = 'judge',
    Speaker = 'speaker'
}
