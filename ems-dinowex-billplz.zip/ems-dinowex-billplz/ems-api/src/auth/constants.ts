
export const jwtConstants = {
    secret: 'secret',
    expiresIn: '3600s',
    refreshSecret: 'refreshSecret',
    refreshExpiresIn: '7200s'
};
  