export interface ILoginInput {
    email: string;
    password: string;
}