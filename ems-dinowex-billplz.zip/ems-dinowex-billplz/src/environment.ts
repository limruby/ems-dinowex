export const environment = {
    apiUrl: "http://localhost:9000/"
}